# GENZ WIFI API foundation

## Setup
1. Install Node.js 20+ and PostgreSQL.
2. Copy `.env.example` to `.env` and set `DATABASE_URL` and a random `JWT_SECRET` (32+ characters).
3. From this folder run:
   - `npm install`
   - `npx prisma generate`
   - `npx prisma migrate dev --name init`
   - `npx tsx prisma/seed.ts`
   - `npm run dev`

API runs at `http://localhost:4000`.

## Endpoints
- `GET /health`
- `POST /api/auth/login` — checks an existing AdminUser record.
- `GET /api/packages`
- `PATCH /api/packages/:id` — Owner JWT required.
- `POST /api/payments/stk-push` — only works after Daraja sandbox credentials and a public callback URL are configured.
- `POST /api/payments/mpesa/callback` — callback receiver.
- `GET /api/vouchers` — Owner JWT required.

## Owner account
The owner email is configured as `komassystems@gmail.com`, but no default password is created. Create the initial owner securely by hashing a password with bcrypt and inserting the AdminUser record. Never ship a default password or expose admin creation publicly.

Example hash generation:
`node -e "require('bcryptjs').hash('YOUR_LONG_PASSWORD',12).then(console.log)"`

Then insert the hash into the AdminUser table using a one-time trusted setup script or Prisma Studio. Remove any temporary setup script after use.

## Payment and security checklist
- Begin with Daraja sandbox credentials.
- Use HTTPS and a publicly reachable callback URL.
- Safaricom callbacks must be reconciled against a pending CheckoutRequestID, amount and phone. Add additional callback authentication/reconciliation controls and idempotency monitoring before production.
- Do not trust browser payment success messages. Only issue customer access after server-verified PAID status.
- Configure callback URL allowlisting and production credentials only after Safaricom onboarding.
- Add audit logs, admin password reset, MFA, backup/restore, monitoring and stricter CORS before launch.

## MikroTik status
This release does not yet provision vouchers to RouterOS. Router credentials are intentionally not wired into a live command endpoint. The next integration step is to implement a restricted RouterOS service that creates time-limited HotSpot users only after a verified PAID payment, then records activation and expiry.
